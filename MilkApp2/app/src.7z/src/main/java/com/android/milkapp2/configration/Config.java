package com.android.milkapp2.configration;

/**
 * 配置类
 * Created by Administrator on 2016/12/21.
 */
public class Config {

    public static final int PORT = 1234;
    public static final String IP = "192.168.191.1";
}
