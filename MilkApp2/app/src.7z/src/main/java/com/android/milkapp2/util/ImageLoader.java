package com.android.milkapp2.util;


public class ImageLoader {



}
